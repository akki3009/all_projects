<!DOCTYPE html>
<html>
<head>
	<title>New Laravel</title>
</head>
<body>
	<!-- <div class="content"> -->
		<h1>Hello Friends</h1>
</body>
</html>