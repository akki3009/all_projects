<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class UserController extends Controller
{
	public function __construct(){
		$this->middleware('second');
	}
	public function showpath(Request $request){
		$uri=$request->path();
		echo '<br>URI:'.$uri;

		$url = $request->url();
		echo '<br>';
		echo 'URL: '.$url;

		$furl=$request->fullUrl();
		echo "<br>";
		echo "Full Url : ".$furl;

		$method = $request->method();
		echo '<br>';
		echo 'Method: '.$method;
	}
	public function show(){
		$uri=$request->path();
		echo "<br>URI : ".$uri;
	}
}
