<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Http\UploadedFile;

class UserRegistration extends Controller
{
	public function setCookie(Request $request){
		$minutes=1;
		$response=new Response('Hello World');
		$response->withCookie(cookie('name','akash',$minutes));
		return $response;
	}
	public function postRegister(Request $request){
		$name=$request->input('name');
		echo "Name :".$name;
		echo "<br>";

		$username=$request->username;
		echo "UserName :".$username;
		echo "<br>";

		$password=$request->password;
		echo "Password :".$password;
		echo "<br>";


		// $data=$request->all();
		// print_r($data);

		// $name=$request->input('name','Akash');
		// echo "Name :".$name;
		// echo "<br>";

		// $input=$request->input();
		// print_r($input);
		
		//query String
		// $name=$request->query('name');
		// echo "Name :".$name;

		//Retrieving Input Via Dynamic Properties
		// $name=$request->name;
		// echo $name;

		//Retrieving JSON Input Values
		//$name = $request->input('user.name');

		// Retrieving A Portion Of The Input Data
		$input = $request->only(['username', 'password']);
		print_r( $input);
		$input = $request->only('username', 'password');
		$input = $request->except(['credit_card']);
		$input = $request->except('credit_card');

		// Determining If An Input Value Is Present
		if ($request->has('name')) {
		    echo "<br>Present Name<br>";
		}

		if ($request->has(['name', 'username'])) {
			echo "Present Data<br>";
		}

		// Determining If An Input Value Is Present and not empty
		if ($request->filled('name')) {
		   echo "Fiiled Name<br>";
		}

		//old input
		// Flashing Input To The Session
		$request->flash();
		$request->flashOnly(['username', 'name']);
		$request->flashExcept('password');

		//Flashing input the redirecting
		// return redirect('form')->withInput();
		// return redirect('form')->withInput(
		// 	$request->except('password')
		// );

		//retrive old value 
		$username=$request->old('username');

		//Cookies
		// Retrieving Cookies From Requests
		$value = $request->cookie('name');

		// Attaching Cookies To Responses
		$value=$request->cookie('name');
		dd($value);

		// return response('Hello World')->cookie('name', 'akki', 1);

		//Retrive Uploaded File
		$file = $request->file('photo');
		$file = $request->photo;

		//File is present or not
		if ($request->hasFile('photo')) {
			//
		}

		// Validating Successful Uploads
		if ($request->file('photo')->isValid()) {
		   //
		}

		// File Paths & Extensions
		$path = $request->photo->path();
		$extension = $request->photo->extension();

		//Stroring Uploaded File
		$path = $request->photo->store('images');
		$path = $request->photo->store('images', 's3');

		//file name to Uploaded File path,name,storage
		$path = $request->photo->storeAs('images', 'filename.jpg');

		//Proxies
		// For that change in TrusProxies in middleware in $proxies

		
	}     
}
