<?php

namespace App\Http\Controllers;

// use Illuminate\Http\Request;
// use App\Http\Requests;
use App\User;
use App\Http\Controllers\Controller;


class UserProfileController extends Controller
{
    public function show(){
        $name="Akash Agrawal";
        echo $name;
    }
    public function show_data($id){
        return view('profile',['user'=>User::findOrFail($id)]);
    }
}
