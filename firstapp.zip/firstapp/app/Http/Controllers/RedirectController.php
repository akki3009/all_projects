<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;


class RedirectController extends Controller
{
    public function index(){
    	//echo "Redirecting to controller action Hello";
    	return view('about');
    }

    public function details($name,$contact){
    	$name="Akash";
    	echo $name;
    	$contact="25424521";
    	echo $contact;
    	// return $name;
    	// return $contact;
    }
}
