<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Http\Middleware\CheckAge;

Route::get('/', function () {
    return view('welcome');
});

//Redirect
Route::get('rc','RedirectController@index');
Route::get('/redirectcontroller',function() {
   return redirect()->action('RedirectController@index');
});

Route::get('/about','RedirectController@index');

//Route::redirect('/here','/about');

//Views
Route::view("/welcome","hello");

//Required Parameters
Route::get('cars/{id}/{name}',function($id,$name){
	return 'Car Name is '.$name.' With id '.$id;
});

//Optional Parameters
Route::get('user/{id}/{name?}',function($id,$name = "Akash"){
	return 'User Name is '.$name.' With id '.$id;
});

//Regular Expression

// Route::get('emp/{name}',function($name){
// 	return "NAme is: ".$name;
// })->where('name','[A-Za-z]+');

Route::get('emp/{name}/{contact}',function($name,$contact){
	return "Name is: ".$name.'  Contact is :'.$contact;
})->where(['name'=>'[A-Za-z]+','contact'=>'[0-9]+']);



// Route::get("deta","RedirectController@details(name,contact)");
// Route::get('det/{name}/{contact}',function($name,$contact){
// 	return redirect()->action("RedirectController@details(name,contact)");
// })->where(['name'=>'[A-Za-z]+','contact'=>'[0-9]+']);

//Global Constraint

Route::get('student/{id}',function($id){
	return "Id is: ".$id;
});

//Encoded Forward Slashes
Route::get('user/{search}',function($search){
	return $search;
})->where('search','.*');

//Named Routes
Route::get('users/profile', 'UserProfileController@show')->name('profile');


//Generating URLs To Named Routes
// Route::get('about',function(){
// 	return view('about');
// });
// $url=route('about');

// OR
// Route::get('about','UserProfileController@about')->name('about');

//Rout Group
Route::group(['prefix'=>'tutorial'], function()  
{  
	Route::get('/first',function()  
	{  
		echo "first route";  
	});  
	Route::get('/second',function()  
	{  
	   echo "second route";  
	});  
	Route::get('/third',function()  
	{  
	   echo "third route";  
	});  
});  
//middleware

// Route::middleware(['age'])->group(function(){
// 	Route::get('/',function(){
// 		echo "First Time";
// 	});
// 	Route::get('data/profile',function(){
// 		echo "Second Time";
// 	});
// });


Route::get('admin/profile', function () {
    echo "Admin/Profile Called";
})->middleware('age');

//OR

Route::get('admin/profile', function () {
    echo "The Admin/Profile Called";
})->middleware(CheckAge::class);

//NameSpaces
// Route::namespace('Admin')->group(function(){

// });

//Subdomain Routing
// Route::domain('{account}.myapp.com')->group(function () {
//     Route::get('user/{id}', function ($account, $id) {
//         //
//     });
// });

//Route Prefixes
// Route::prefix('admin')->group(function () {
//     Route::get('users', function () {
//         // Matches The "/admin/users" URL
//     });
// });


//Route Name prefixes
// Route::name('admin.')->group(function () {
//     Route::get('users', function () {
//         return view('welcome');
//     })->name('users');
// });


//Route Model implicite Binding
Route::get('api/users/{user}', function (App\User $user) {
    return $user->email;
});
// Route::get('/tasks{task}','TaskController@index');

//Explicit 
Route::get('profile/{user}', function (App\User $user) {

});

//Customizing the Resolution logic


//fallback
Route::fallback(function(){
	return "Hm U land some error";
});


//RAte Limiting
// Route::middleware('auth:api', 'throttle:60,1')->group(function () {
// 	Route::get('/user', function () {

// 	});
// });
// Route::middleware('throttle:4,1')->get('/',function(){
// 	return "Hello Throttle";
// });


//Dynamic Rate Limiting
// Route::middleware('auth:api', 'throttle:rate_limit,1')->group(function () {
// 	Route::get('/user', function () {
//     	return "Hello";
//     });
// });


//Accessing The Current Route
//Route::getCurrentRoute()->getPath();
// return \Request::route()->getName();
//return \Route::currentRouteName();
// $action = Route::currentRouteAction();


//Middleware Group
Route::get('/',function(){
	echo "Hello";
})->middleware('web');

Route::group(['middleware' => ['web']], function () {

});

//MiddleWare Parameters


//Today //


//Excluding URIs From CSRF Protection
//Add the URI in VerifyVsrfToken in $except method.


//X-CSRF-TOKEN
// <meta name="csrf-token" content="{{ csrf_token() }}">
/*$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});*/

//Basic Controller
Route::get('control/{id}','UserProfileController@show');

//Single Action Controllers
Route::get('user/{id}', 'ShowProfile');

//Controller Middleware
Route::get('/profiler', 'UserController@show')->middleware('auth');

//Eaxmple
Route::get('/usercontroller/path',['middleware'=>'First','uses'=>'UserController@showpath']);

//To Show path ::  php artisan route:list

//Resource Controller
Route::resource('/my','MyController');

//Specifying The Resource Model
// php artisan make:controller MyController --resource --model=User

//Partial Resource Routes
Route::resource('myd', 'MyController')->only([
    'index', 'show'
]);
// // Route::resource('photos', 'PhotoController')->except([
// //     'create', 'store', 'update', 'destroy'
// // ]);


// //API Resource Routes : To create template such as except create and edit.
Route::apiResource('mye','MyController');

// // php artisan make:controller API/MyController --api  Which can not include create or edit.


// //Naming Resource Routes
Route::resource('my', 'MyController')->names([
    'create' => 'my.build'
]);

// //Naming Resource Route Parameters
Route::resource('users', 'MyController')->parameters([
    'users' => 'admin_user'
]);

// //Localizing Resource URIs
// Route::resource('myis','MyController');
Route::resource('foo', 'MyController', array(
    'names' => array(
        'create'    => 'nouveau',
        'edit'      => 'modifier',
    )
));

//Supplementing Resource Controllers
Route::get('our/help', 'MyController@create');
Route::resource('our', 'MyController');


//Request

//input data
Route::get('/register',function(){
	return view('register');
});
Route::post('/user/register',array('uses'=>'UserRegistration@postRegister'));

//input from query
// $query=$request->query();

//Dynamic Data
Route::get('/register',function(){
	return view('register');
});
Route::post('/user/register',array('uses'=>'UserRegistration@postRegister'));

//Cookie
Route::get('/cookie/set','UserRegistration@setCookie');
Route::get('/cookie/get','UserRegistration@postRegister');

//Response
Route::get('/',function(){
	return "Hello World";
});
Route::get('/',function(){
	return[1,2,3];
});

//Response Objects
Route::get('home',function(){
	return response('Hello World',200)
	->header('Content-Type','text-plain');
});

//Attaching Headers To Responses
Route::get('goto',function(){
	return response('Hello')
	->header('Content-Type',$type)
	->header('X-Header-One', 'Header Value')
    ->header('X-Header-Two', 'Header Value');
});

// return response($content)
// 	->withHeaders([
// 		'Content-Type'=>$type,
// 		'X-Header-One'=>'Header Value',
// 		'X-Header-Two'=>'Header Value',
// 	]);


//Cache Control Middleware
Route::middleware('cache.headers:public;max_age=2628000;etag')->group(function() {
    Route::get('privacy', function () {

    });
    Route::get('terms', function () {
    	
    });
});

//Attaching cookie value to Responses
Route::get('cok',function(){
$content="Hello ffriends";
	return response($content)
			->header('Content-Type', 'text-plain')
			->cookie('name', 'akash', 1);
});


// These cookies will be attached to the outgoing response before it is sent to the browser:
Cookie::queue(Cookie::make('name', 'akasha', 1));
Cookie::queue('name', 'kkikik', 1);

//Cookie Ecnryption

// App\Http\Middleware\EncryptCookies write in $except variable to disable the cookie.
// protected $except = [
//     'cookie_name',
// ];

//Redirects
Route::get('dashboard', function () {
    return redirect('home/dashboard');
});

Route::post('user/profile', function () {
    // Validate the request...

    return back()->withInput();
});

// Redirecting To Named Routes
// return redirect()->route('login');
// return redirect()->route('profile', ['id' => 1]);

// Populating Parameters Via Eloquent Models
//return redirect()->route('profile', [$user]);

// Redirecting To Controller Actions
// return redirect()->action('HomeController@index');
// return redirect()->action(
//     'UserController@profile', ['id' => 1]
// );

Route::get('gogl',function(){
	return redirect()->away('https://www.google.com');
});

// View Responses
// return response()
// 		->view('hello', $data, 200)
// 		->header('Content-Type', $type);

//JSON Response
return response()->json([
    'name' => 'Abigail',
    'state' => 'CA'
]);

//file Downloads
return response()->download($pathToFile, $name, $headers);
return response()->download($pathToFile)->deleteFileAfterSend();

//File Responses
return response()->file($pathToFile);
return response()->file($pathToFile, $headers);

//Response Macros
Route::get("/helo",function(){
	return response()->caps('foo');
});