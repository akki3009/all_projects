@component('mail::message')
# Welcome {{$user->name}}

This is Test Mail

@component('mail::button', ['url' => ''])
Send To Verify
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
