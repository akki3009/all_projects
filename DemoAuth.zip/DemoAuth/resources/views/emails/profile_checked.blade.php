@component('mail::message')
# Hii {{$user->name}}

Someone Checked Your Profie for more info visit to our site.   

@component('mail::button', ['url' => 'http://localhost:8000/event'])
Visit Now
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
