<?php

use App\Events\SomeOneCheckedProfile;
use App\Facades\PaymentFacades;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PostController;
use App\Jobs\SendTestMailJob;
use App\Mail\SendMarkdownMail;
use App\Mail\SendTestMail;
use App\Models\User;
use App\Notifications\OrderShippedNotification;
use App\PaymentService\PaymentApiContainer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::middleware(['auth:sanctum', 'verified'])->get('/dashboard', function () {
    return view('dashboard');
})->name('dashboard');

Route::get('/serviceContainer', [HomeController::class,'serviceContainer']);
Route::get('/serviceProvider', [HomeController::class,'serviceProvider']);
Route::get('/serviceProvid', [HomeController::class,'serviceProvid']);
Route::get('/facade', [HomeController::class,'facade']);
Route::get('/sendEmail', [HomeController::class,'sendEmail']);
Route::get('/queueEmail', [HomeController::class,'queueEmail']);
Route::get('/event', [HomeController::class,'event']);
Route::get('/notification', [HomeController::class,'notification']);

Route::get('/autorize',[PostController::class,'index']);
Route::get('/blog',[BlogController::class,'blogData']);






