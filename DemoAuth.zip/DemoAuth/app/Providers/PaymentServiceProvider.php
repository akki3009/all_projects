<?php

namespace App\Providers;

use App\PaymentService\PaymentApiContainer;
use Illuminate\Contracts\Support\DeferrableProvider;
use Illuminate\Support\ServiceProvider;

class PaymentServiceProvider extends ServiceProvider //implements DeferrableProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(PaymentApiContainer::class,function(){
            return new PaymentApiContainer("thetransector-".rand(0,1500));
        },true); 

        // $paymentapi = new PaymentApiContainer("thetestcoder-".rand(1,100));
        // $this->app->instance(PaymentApiContainer::class,$paymentapi);
    }


    // DeferableProvider Method for calling Specific Route.
    // public function provides()
    // {
    //     return [PaymentApiContainer::class];
    // }



    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
