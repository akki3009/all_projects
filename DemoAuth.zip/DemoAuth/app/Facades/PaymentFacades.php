<?php

namespace App\Facades;

use App\PaymentService\PaymentApiContainer;
use Illuminate\Support\Facades\Facade;

class PaymentFacades extends Facade
{
    public static function getFacadeAccessor(){
        return PaymentApiContainer::class;
    }
}