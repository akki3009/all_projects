<?php

namespace App\Listeners;

use App\Events\SomeOneCheckedProfile;
use App\Jobs\SendProfileCheckedJob;
use App\Mail\ProfileCheckedMail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;

class SendProfileListener implements ShouldQueue
{

    public $delay = 5;
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  SomeOneCheckedProfile  $event
     * @return void
     */
    public function handle(SomeOneCheckedProfile $event)
    {
        // $event->user;
        // SendProfileCheckedJob::dispatch($event->user)->delay(now()->addSeconds(3));
        Mail::to($event->user->email)
        ->send(new ProfileCheckedMail($event->user));
    }
}
