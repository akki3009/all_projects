<?php

namespace App\Http\Controllers;

use App\Events\SomeOneCheckedProfile;
use App\Facades\PaymentFacades;
use App\Jobs\SendTestMailJob;
use App\Mail\SendTestMail;
use App\Models\User;
use App\Notifications\OrderShippedNotification;
use App\PaymentService\PaymentApiContainer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class HomeController extends Controller
{
    public function serviceContainer(PaymentApiContainer $payment)
    {
        dump($payment->payme());
        dd(app());
    }
    public function serviceProvider(PaymentApiContainer $payment)
    {
        dump($payment->pay());
    }
    public function serviceProvid()
    {
        dd(app(PaymentApiContainer::class), app(PaymentApiContainer::class));
    }
    public function facade()
    {
        return PaymentFacades::pay();
    }
    public function sendEmail()
    {
        // Mail::send('email',$data,function($message){
        //     $message->to("akash@gmail.com","Laravel User")
        //     ->subject("Laravel Demo");
        // });

        Mail::to("akash@gmail.com", "New User Test")->send(new SendTestMail());
        // Mail::to("akash@gmail.com","New User Test")->send(new SendMarkdownMail());
        echo "Mail Sent";
    }
    public function queueEmail()
    {
        // dispatch(function(){

        // })->delay(now()->addSeconds(5));

        // dispatch(new SendTestMailJob())->delay(now()->addSeconds(5));

        $user = User::findOrFail(2);
        dispatch(new SendTestMailJob($user))->delay(now()->addSeconds(5));
        echo "Mail Sent With Queue Job Process";
    }
    public function event()
    {
        $user = User::inRandomOrder()->first();
        // event(new SomeOneCheckedProfile($user));
        SomeOneCheckedProfile::dispatch($user);
        echo $user->name . 'Your Profile Loaded';
    }
    public function notification()
    {
        $user = User::inRandomOrder()->first();
        $user->notify((new OrderShippedNotification())->delay(5));
    }
}
