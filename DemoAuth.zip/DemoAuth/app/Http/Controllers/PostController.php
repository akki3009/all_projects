<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;

class PostController extends Controller
{
    public function index()
    {
        $post = Post::find(1);
        // dd(Gate::allows('edit',$post));
        return view('autorize',compact('post'));
    }
}
