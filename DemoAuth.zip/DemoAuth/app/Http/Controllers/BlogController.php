<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use Illuminate\Http\Request;

class BlogController extends Controller
{
    public function blogData(Request $request)
    {
        $blog = Blog::find(1);
        dd($blog);
    }
}
