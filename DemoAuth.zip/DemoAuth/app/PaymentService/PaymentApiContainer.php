<?php

namespace App\PaymentService;

class PaymentApiContainer
{

    private $transaction_id;

    public function __construct($transaction_id)
    {
        $this->transaction_id = $transaction_id;
    }
    public function pay() 
    {
        return [
            'amount' => 123,
            'transaction' => $this->transaction_id,
        ];
    }
    public function payme(){
        return "Payment Paid Successfully";
    }
}

