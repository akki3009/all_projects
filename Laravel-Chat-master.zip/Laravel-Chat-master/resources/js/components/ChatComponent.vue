<template>
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">Chats</div>
            <div class="card-body">
                <chat-messages-component></chat-messages-component>
                <chat-form-component></chat-form-component>

            </div>
        </div>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('ChatComponent mounted.')
        }
    }
</script>
